const showMoreButtons = document.querySelectorAll('.show-more');
showMoreButtons.forEach(button => {
  button.addEventListener('click', () => {
    const destinationText = button.parentNode;
    destinationText.classList.toggle('show');
  });
});

function validateForm(event) {
  event.preventDefault();
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();
  if (name === "" || email === "" || message === "") {
    alert("All fields must be filled out.");
    return false;
  }
  alert("Form submitted successfully!");
  return true;
}